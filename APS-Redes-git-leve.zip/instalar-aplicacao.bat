@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo.
echo Instalando APS Redes...
echo.

where java >nul 2>nul
if errorlevel 1 (
    echo ERRO: Java 17+ nao encontrado no PATH.
    echo Instale o JDK 17 ou superior e tente novamente.
    pause
    exit /b 1
)

if not exist "config" mkdir "config"

if not exist "config\app.properties" (
    echo APS_CHAT_PORT=5050>"config\app.properties"
    echo APS_STORAGE_DIR=server-storage>>"config\app.properties"
    echo APS_ADMIN_PASSWORD=admin123>>"config\app.properties"
    echo APS_MEMBER_PASSWORD=membro123>>"config\app.properties"
    echo Arquivo config\app.properties criado.
)
if not exist "config\database.properties" (
    echo DB_ENABLED=false>"config\database.properties"
    echo DB_URL=jdbc:mysql://localhost:3306/aps_redes?useSSL=false^&allowPublicKeyRetrieval=true^&serverTimezone=UTC>>"config\database.properties"
    echo DB_USER=root>>"config\database.properties"
    echo DB_PASSWORD=>>"config\database.properties"
    echo Arquivo config\database.properties criado.
)
if not exist "server-storage" mkdir "server-storage"
if not exist "server-storage\logs" mkdir "server-storage\logs"
if not exist "server-storage\relatorios-criados" mkdir "server-storage\relatorios-criados"

if not exist "lib\javafx-controls-21.0.5-win.jar" call "%~dp0scripts\centralizar-jars.bat"

set "NEED_BUILD="
if not exist "target\classes\aps" set "NEED_BUILD=1"
if not exist "lib\javafx-controls-21.0.5-win.jar" set "NEED_BUILD=1"

if defined NEED_BUILD (
    echo.
    echo Arquivos compilados ou dependencias nao encontrados. Compilando aplicacao...
    call "%~dp0build.bat" /nopause
    if errorlevel 1 (
        echo.
        echo Instalacao interrompida: build falhou.
        if /i not "%~1"=="/nopause" pause
        exit /b 1
    )
) else (
    echo Aplicacao compilada encontrada. Nao foi necessario recompilar.
)

echo.
echo Instalacao concluida.
echo.
echo Proximos passos:
echo 1. Edite os arquivos em config\ se quiser ativar MySQL.
echo 2. Para MySQL, rode: setup-mysql.bat
echo 3. Abra: iniciar-aplicacao.bat
echo.
if /i not "%~1"=="/nopause" pause
