@echo off
setlocal
cd /d "%~dp0"

echo.
echo Preparando modo demonstracao...
echo.

if not exist "server-storage\relatorios-criados" mkdir "server-storage\relatorios-criados"

set "DEMO_FILE=server-storage\relatorios-criados\relatorio-demo.txt"
if not exist "%DEMO_FILE%" (
    > "%DEMO_FILE%" echo Relatorio APS Redes - Demonstracao
    >> "%DEMO_FILE%" echo Canal: Equipe Alfa
    >> "%DEMO_FILE%" echo Autor: Demo
    >> "%DEMO_FILE%" echo.
    >> "%DEMO_FILE%" echo Este arquivo serve para testar o upload e a leitura dentro da aba Relatorios.
)

echo Relatorio exemplo criado em %DEMO_FILE%
echo Login membro: membro123
echo Login admin: admin123
echo.
echo Abrindo aplicacao...
call "%~dp0iniciar-aplicacao.bat"
