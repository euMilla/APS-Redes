CREATE DATABASE IF NOT EXISTS aps_redes
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE aps_redes;

CREATE TABLE IF NOT EXISTS aps_auth (
    key_name VARCHAR(40) PRIMARY KEY,
    password_hash VARCHAR(255) NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS aps_user_access (
    username VARCHAR(80) PRIMARY KEY,
    role_name VARCHAR(40) NOT NULL DEFAULT 'Membro',
    allowed_channels VARCHAR(255) NOT NULL DEFAULT 'Equipe Alfa',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS aps_reports (
    id VARCHAR(80) PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    owner_name VARCHAR(120) NOT NULL,
    room_name VARCHAR(80) NOT NULL,
    file_size BIGINT NOT NULL,
    uploaded_at_epoch BIGINT NOT NULL,
    stored_name VARCHAR(320) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_report_room_name (room_name, file_name)
);

CREATE TABLE IF NOT EXISTS aps_audit_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_type VARCHAR(60) NOT NULL,
    username VARCHAR(120) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO aps_user_access(username, role_name, allowed_channels)
VALUES
  ('membro-demo', 'Membro', 'Equipe Alfa'),
  ('inspetor-demo', 'Fiscal', 'Equipe Alfa|Equipe Beta'),
  ('coordenador-demo', 'Coordenador', 'Equipe Alfa|Equipe Beta|Equipe Gama|Central Operacional');
