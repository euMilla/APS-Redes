@echo off
setlocal
cd /d "%~dp0"

echo.
echo Criando banco MySQL aps_redes...
echo.

where mysql >nul 2>nul
if errorlevel 1 (
    echo ERRO: cliente mysql nao encontrado no PATH.
    echo Instale MySQL Server/Workbench ou rode database\schema.sql manualmente.
    pause
    exit /b 1
)

set /p MYSQL_USER=Usuario MySQL [root]: 
if "%MYSQL_USER%"=="" set "MYSQL_USER=root"

mysql -u "%MYSQL_USER%" -p < "database\schema.sql"
if errorlevel 1 (
    echo.
    echo Falha ao criar banco. Confira usuario/senha do MySQL.
    pause
    exit /b 1
)

if not exist "config" mkdir "config"
set /p APP_DB_PASSWORD=Senha que o sistema usara no MySQL [vazia]: 
(
    echo DB_ENABLED=true
    echo DB_URL=jdbc:mysql://localhost:3306/aps_redes?useSSL=false^&allowPublicKeyRetrieval=true^&serverTimezone=UTC
    echo DB_USER=%MYSQL_USER%
    echo DB_PASSWORD=%APP_DB_PASSWORD%
) > "config\database.properties"

echo.
echo Banco criado/atualizado com sucesso.
echo Configuracao gravada em config\database.properties.
echo.
pause
